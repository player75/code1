// 引入共用的依赖
import Vue from 'vue'
import Router from 'vue-router'
// 引入需要展示的组件
import HelloWorld from '@/components/HelloWorld'
import father from '../components/father.vue'
import cart from '../components/cart.vue'
import error from '../components/error.vue'

Vue.use(Router)

export default new Router({
  // 路由模式：vue默认使用hash模式（哈希） 
  mode: 'history',
  routes: [
    // 路由表:url和组件的对应关系,严格的字符串匹配
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/father',
      name: 'father',
      component: father
    },
    {
      path: '/cart',
      name: 'cart',
      component: cart
    },
    // 地址输入错误的处理方式1
    // {
    //   path: '*',
    //   // 通配符，可以匹配所有的路径，但是优先级低，先匹配上面的准确的路径
    //   component: error
    // }
    // 地址输入错误的处理方式2
    {
      path: '/error',
      component: error
    },
    {
      path: '*',
      // 重定向到指定页面
      redirect: '/error'
    }
  ]
})
