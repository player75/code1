<template>
  <div>
    <p>注册</p>
    <input type="text" placeholder="请输入用户名" v-model="username">  
  </div>  
</template>

<script>
export default {
  data() {
    return {
      username:''
    }
  },
}
</script>

<style>

</style>