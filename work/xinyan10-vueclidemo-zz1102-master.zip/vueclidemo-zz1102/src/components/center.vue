<template>
  <div class="center">
    <p>我是正文</p>
  </div>  
</template>

<script>
export default {

}
</script>

<style>
.center {
  float: left;
}
</style>