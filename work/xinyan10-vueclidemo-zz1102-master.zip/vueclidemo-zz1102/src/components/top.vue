<template>
  <div>
      <header>vue.js</header>
  </div>  
</template>

<script>
export default {

}
</script>

<style scoped>
  header {
    border-bottom: 1px solid #666;
  }
</style>